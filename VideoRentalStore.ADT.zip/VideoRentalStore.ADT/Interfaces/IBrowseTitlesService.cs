﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VideoRentalStore.Core.ModelClasses;
using VideoRentalStore.Entities;

namespace VideoRentalStore.ADT.Interfaces
{
    public interface IBrowseTitlesService
    {
        Task<List<Video>> GetVideos();
        Task<List<Genre>> GetGenres();
        Task<VideosModel> SearchWithFilters(string searchTerm, DateTime startDate, DateTime endDate, List<Genre> genres);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ninject.Modules;

namespace VideoRentalStore.ADT.Interfaces.Injection
{
    public interface IDependencyResolver
    {
        INinjectModule[] GetVideos();
    }
}

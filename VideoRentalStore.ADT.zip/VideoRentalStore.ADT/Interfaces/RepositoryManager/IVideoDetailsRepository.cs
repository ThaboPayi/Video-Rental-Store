﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VideoRentalStore.Core.ModelClasses;

namespace VideoRentalStore.ADT.Interfaces.RepositoryManager
{
    public interface IVideoDetailsRepository
    {
        Task<VideoDetailsModel> GetVideoDetasilsByVideoID(Guid videoId);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VideoRentalStore.Core.ModelClasses;
using VideoRentalStore.Entities;

namespace VideoRentalStore.ADT.Interfaces.RepositoryManager
{
    public interface ILatestReleasesRepository
    {
        Task<List<Video>> SearchByTerm(string searchTerm);
        Task<List<Video>> GetLatestReleases();
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace VideoRentalStore.ADT.Interfaces.RepositoryManager
{
    public interface IRepositoryManager
    {
        IBrowseTitleRepository BrowseTitleRepository { get; set; }
        ILatestReleasesRepository LatestReleasesRepository { get; set; }
        IRentalRepository RentalRepository { get; set; }
        IVideoDetailsRepository VideoDetailsRepository { get; set; }
        void Dispose();
        int SaveChanges();
        Task<int> SaveChangesAsync();
        Task<int> SaveChangesAsync(CancellationToken cancellationToken);
    }
}

﻿using System.Data.Entity.ModelConfiguration;
using VideoRentalStore.Entities;

namespace VideoRentalStore.Database.EntitiesConfigurations
{
    internal sealed class VideoConfiguration : EntityTypeConfiguration<Video>
    {
        public VideoConfiguration()
        {
            ToTable("Videos");

            HasMany(e => e.Genres)
                .WithMany(e => e.Videos)
                .Map(ur =>
                {
                    ur.MapLeftKey("VideoId");
                    ur.MapRightKey("GenreId");
                    ur.ToTable("VideoGenres");
                });

            HasMany(e => e.HeadLineActors)
                .WithMany(e => e.Videos)
                .Map(ur =>
                {
                    ur.MapLeftKey("VideoId");
                    ur.MapRightKey("HeadLineActorId");
                    ur.ToTable("VideoHeadLineActors");
                });
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VideoRentalStore.Entities;

namespace VideoRentalStore.Database.EntitiesConfigurations
{
    public class GenreConfiguration : EntityTypeConfiguration<Genre>
    {
        public GenreConfiguration()
        {
            HasMany(e => e.Videos)
                .WithMany(e => e.Genres)
                .Map(ur =>
                {
                    ur.MapLeftKey("VideoId");
                    ur.MapRightKey("GenreId");
                    ur.ToTable("VideoGenres");
                });
        }
    }
}

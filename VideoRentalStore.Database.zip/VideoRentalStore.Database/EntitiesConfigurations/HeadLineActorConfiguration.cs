﻿using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VideoRentalStore.Entities;

namespace VideoRentalStore.Database.EntitiesConfigurations
{
    public class HeadLineActorConfiguration : EntityTypeConfiguration<HeadLineActor>
    {
        public HeadLineActorConfiguration()
        {
            HasMany(e => e.Videos)
                .WithMany(e => e.HeadLineActors)
                .Map(ur =>
                {
                    ur.MapLeftKey("VideoId");
                    ur.MapRightKey("HeadLineActorId");
                    ur.ToTable("VideoHeadLineActors");
                });
        }
    }
}

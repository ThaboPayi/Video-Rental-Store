namespace VideoRentalStore.Database.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class StuffChanging : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Genres",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        VideoGenre = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.HeadLineActors",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        VideoId = c.Guid(nullable: false),
                        VideoHeadLineActor = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Rentals",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        UserId = c.Int(nullable: false),
                        VideoId = c.Guid(nullable: false),
                        RentDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Videos",
                c => new
                    {
                        Id = c.Guid(nullable: false),
                        Tittle = c.String(),
                        ReleaseDate = c.DateTime(nullable: false),
                        Director = c.String(),
                        Genre = c.Guid(nullable: false),
                        ImageDirectory = c.String(),
                        IsRented = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Videos");
            DropTable("dbo.Rentals");
            DropTable("dbo.HeadLineActors");
            DropTable("dbo.Genres");
        }
    }
}

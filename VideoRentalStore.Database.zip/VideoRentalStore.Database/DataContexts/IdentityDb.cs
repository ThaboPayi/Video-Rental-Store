﻿//using Microsoft.AspNet.Identity.EntityFramework;
//using VideoRentalStore.Entities;

//namespace VideoRentalStore.Database.DataContexts
//{
//    public class IdentityDb : IdentityDbContext<ApplicationUser, Guid>
//    {
//        public IdentityDb()
//            : base("DefaultConnection")
//        {
//        }

//        public static IdentityDb Create()
//        {
//            return new IdentityDb();
//        }
//    }
//}
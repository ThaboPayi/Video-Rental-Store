﻿using System.Data.Entity;
using VideoRentalStore.Database.EntitiesConfigurations;
using VideoRentalStore.Entities;

namespace VideoRentalStore.Database.DataContexts
{
    public class VideoRentalStoreDb : DbContext
    {
        private readonly string _nameOrConnectionString = "DefaultConnection";
        public VideoRentalStoreDb()
            : base("DefaultConnection")
        {

        }
        public VideoRentalStoreDb(string nameOrConnectionString)
            : base("DefaultConnection")
        {
            _nameOrConnectionString = nameOrConnectionString;
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new VideoConfiguration());
        }
        public DbSet<Video> Videos { get; set; }
        public DbSet<Rental> Rentals { get; set; }
        public DbSet<Genre> Genres { get; set; }
        public DbSet<HeadLineActor> HeadLineActors { get; set; }
        public DbSet<VideoCopy> VideoCopies { get; set; }
    }
}
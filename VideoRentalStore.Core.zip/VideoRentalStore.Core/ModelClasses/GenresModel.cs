﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoRentalStore.Core.ModelClasses
{
    public class GenresModel
    {
        public Guid Id { get; set; }

        public string GenreDescription { get; set;}
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VideoRentalStore.Entities;

namespace VideoRentalStore.Core.ModelClasses
{
    public class RentalModel
    {
        public int UserId { get; set; }
        public Guid VideoId { get; set; }
        public DateTime RentDate { get; set; }
    }
}

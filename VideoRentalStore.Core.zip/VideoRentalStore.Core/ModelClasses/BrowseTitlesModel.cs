﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VideoRentalStore.Entities;

namespace VideoRentalStore.Core.ModelClasses
{
    public class BrowseTitlesModel
    {
        public List<Video> BrowseTitlesList { get; set; }
        public Guid VideoId { get; set; }
        public string VideoTitle { get; set; }
        public string VideoDirector { get; set; }
        public DateTime ReleaseDate { get; set; }
        public List<HeadLineActor> HeadLineActors { get; set; }
        public List<Genre> Genres { get; set; }
        [Display(Name = "Search By")]
        public string SearchTerm { get; set; }
        [Display(Name = "Start Date")]
        public DateTime StartDate { get; set; }
        [Display(Name = "End Date")]
        public DateTime EndDate { get; set; }
        public string GenresForSearch { get; set; }
    }
}

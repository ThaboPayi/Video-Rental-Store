﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading.Tasks;
using VideoRentalStore.ADT.Interfaces;
using VideoRentalStore.Core.ModelClasses;
using VideoRentalStore.Services.Services;

namespace VideoRentalStore.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILatestReleasesService _latestReleases;

        public HomeController(ILatestReleasesService latestReleasesService)
        {
            _latestReleases = latestReleasesService;
        }
        public async Task<ActionResult> IndexUnAuth()
        {
            LatestReleasesModel lrm = new LatestReleasesModel()
            {
                LatestReleasesList = await _latestReleases.GetLatestReleases()
            };

            return View(lrm);
        }

        public async Task<ActionResult> Index()
        {
            LatestReleasesModel lrm = new LatestReleasesModel()
            {
                LatestReleasesList = await _latestReleases.GetLatestReleases()
            };

            return View(lrm);
        }

        [AllowAnonymous]
        public async Task<ActionResult> searchVideo(string searchValue)
        {
            LatestReleasesModel lrm;
            if (!string.IsNullOrEmpty(searchValue))
            {
                lrm = new LatestReleasesModel()
                {
                    LatestReleasesList = await _latestReleases.SearchByTerm(searchValue)
                };
                return PartialView("_LatestReleasesPartial", lrm);
            }
            else
            {
                lrm = new LatestReleasesModel()
                {
                    LatestReleasesList = await _latestReleases.GetLatestReleases()
                };
                return PartialView("_LatestReleasesPartial", lrm);
            }
        }

        public ActionResult RedirectToBrowseTitles()
        {
            return RedirectToAction("Index", "BrowseTitles");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using VideoRentalStore.ADT.Interfaces;
using VideoRentalStore.Core.ModelClasses;

namespace VideoRentalStore.Web.Controllers
{
    public class BrowseTitlesController : Controller
    {
        private readonly IBrowseTitlesService _browseTitles;

        public BrowseTitlesController(IBrowseTitlesService browseTitlesService)
        {
            _browseTitles = browseTitlesService;
        }
        // GET: BrowseTitles
        public async Task<ActionResult> Index()
        {
            BrowseTitlesModel lrm = new BrowseTitlesModel()
            {
                BrowseTitlesList = await _browseTitles.GetVideos(),
                Genres = await _browseTitles.GetGenres()
            };
            return View(lrm);
        }
    }
}
﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(VideoRentalStore.Web.Startup))]
namespace VideoRentalStore.Web
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}

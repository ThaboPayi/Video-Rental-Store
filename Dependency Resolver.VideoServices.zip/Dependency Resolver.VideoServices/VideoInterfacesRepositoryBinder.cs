﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ninject.Modules;
using VideoRentalStore.ADT.Interfaces;
using VideoRentalStore.ADT.Interfaces.RepositoryManager;
using VideoRentalStore.Repository.Repositories;
using VideoRentalStore.Services.Services;

namespace Dependency_Resolver.VideoServices
{
    public class VideoInterfacesRepositoryBinder : NinjectModule
    {
        public override void Load()
        {
            Bind<IRepositoryManager>().To<RepositoryManager>();
            Bind<IBrowseTitleRepository>().To<BrowseTitlesRepository>();
            Bind<ILatestReleasesRepository>().To<LatestReleasesRepository>();
            Bind<IRentalRepository>().To<RentalRepository>();
            Bind<IVideoDetailsRepository>().To<VideoDetailsRepository>();
            Bind<IBrowseTitlesService>().To<BrowseTitlesService>();
            Bind<ILatestReleasesService>().To<LatestReleasesService>();
            Bind<IRentalService>().To<RentalService>();
            Bind<IVideoDetailsService>().To<IVideoDetailsService>();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoRentalStore.Entities
{
    public class HeadLineActor
    {
        [Key]
        public Guid Id { get; set; }
        public string HeadLineActorText { get; set; }
        public List<Video> Videos { get; set; }
        public int HeadLineActorOrder { get; set; }
    }
}

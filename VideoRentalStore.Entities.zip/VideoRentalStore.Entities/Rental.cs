﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoRentalStore.Entities
{
    public class Rental
    {
        [Key]
        public Guid Id { get; set; }
        public int UserId { get; set; }
        public Guid VideoId { get; set; }
        public DateTime RentDate { get; set; }
    }
}

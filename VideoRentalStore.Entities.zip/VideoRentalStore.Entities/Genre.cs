﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoRentalStore.Entities
{
    public  class Genre
    {
        [Key]
        public Guid Id { get; set; }
        public string GenreText { get; set; }
        public List<Video> Videos { get; set; }
        public int GenreOrder { get; set; }
    }
}

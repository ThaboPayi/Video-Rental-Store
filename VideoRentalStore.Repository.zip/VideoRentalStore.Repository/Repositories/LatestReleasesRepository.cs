﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using VideoRentalStore.ADT.Interfaces.RepositoryManager;
using VideoRentalStore.Core.ModelClasses;
using VideoRentalStore.Database.DataContexts;
using VideoRentalStore.Entities;

namespace VideoRentalStore.Repository.Repositories
{
    public class LatestReleasesRepository : ILatestReleasesRepository
    {
        private readonly VideoRentalStoreDb _context;

        public LatestReleasesRepository(VideoRentalStoreDb dbContext)
        {
            _context = dbContext;
        }

        public async Task<List<Video>> SearchByTerm(string searchTerm)
        {
            List<Video> vs = new List<Video>();

            LatestReleasesModel vsModel = new LatestReleasesModel();

            var headLineActors = await _context.HeadLineActors.Where(p => p.HeadLineActorText.Contains(searchTerm))
                .ToListAsync();

            var videos = await _context.Videos.Where(p => p.Tittle.Contains(searchTerm) || p.Director.Contains(searchTerm)).ToListAsync();

            var vh = headLineActors.Join(videos, h => h.Id, v => v.Id, (h, v) => new { v = v, h = h }).Distinct().ToList().
                Select(p => new
                {
                    VideoID = p.v.Id,
                    Tittle = p.v.Tittle,
                    Director = p.v.Director,
                    Genres = p.v.Genres,
                    HeadLineActors = p.v.HeadLineActors,
                    ReleaseDate = p.v.ReleaseDate
                });

            foreach (var items in vh)
            {
                vs.Add(
                    new Video
                    {
                        Tittle = items.Tittle,
                        Director = items.Director,
                        Genres = items.Genres,
                        HeadLineActors = items.HeadLineActors,
                        ReleaseDate = items.ReleaseDate,
                    });
            }

            vsModel = new LatestReleasesModel
            {
                LatestReleasesList = vs,
            };

            return vs;
        }

        public async Task<List<Video>> GetLatestReleases()
        {
            var latestReleasesList = await _context.Videos.OrderBy(r => r.ReleaseDate).Distinct().Take(6).ToListAsync();
            return latestReleasesList;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VideoRentalStore.ADT.Interfaces.RepositoryManager;
using VideoRentalStore.Core.ModelClasses;
using VideoRentalStore.Database.DataContexts;
using VideoRentalStore.Entities;

namespace VideoRentalStore.Repository.Repositories
{
    public class RentalRepository : IRentalRepository
    {
        private readonly VideoRentalStoreDb _context;

        public RentalRepository(VideoRentalStoreDb dbContext)
        {
            _context = dbContext;
        }

        public async Task RentVideoAsync(RentalModel rental)
        {
            
            Rental isVideoRented = await _context.Rentals.FirstOrDefaultAsync(p => p.Id == rental.VideoId);
            if (isVideoRented == null)
            {
                isVideoRented = new Rental
                {
                    Id = new Guid(),
                    UserId = rental.UserId,
                    VideoId = rental.VideoId,
                    RentDate = DateTime.Now                 
                };
                _context.Rentals.AddOrUpdate(isVideoRented);
                await _context.SaveChangesAsync();
            }
        }
    }
}

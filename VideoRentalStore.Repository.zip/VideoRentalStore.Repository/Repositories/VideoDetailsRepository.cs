﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using VideoRentalStore.ADT.Interfaces.RepositoryManager;
using VideoRentalStore.Core.ModelClasses;
using VideoRentalStore.Database.DataContexts;
using VideoRentalStore.Entities;

namespace VideoRentalStore.Repository.Repositories
{
    public class VideoDetailsRepository : IVideoDetailsRepository
    {
        private readonly VideoRentalStoreDb _context;

        public VideoDetailsRepository(VideoRentalStoreDb dbContext)
        {
            _context = dbContext;
        }

        public async Task<VideoDetailsModel> GetVideoDetasilsByVideoID(Guid videoId)
        {
            Video video = await _context.Videos.FirstOrDefaultAsync(r => r.Id == videoId);
            if (video != null)
                return new VideoDetailsModel
                {
                    VideoId = video.Id,
                    VideoTitle = video.Tittle,
                    VideoDirector = video.Director,
                    ReleaseDate = video.ReleaseDate,
                    Genres = video.Genres,
                    HeadLineActors = video.HeadLineActors
                };
            return null;
        }
        //private async Task<List<Genre>> GetGenresByVideoID(Guid videoId)
        //{
        //    return await _context.Genres.Where(x => x.VideoId == videoId).ToListAsync();
        //}
        //private async Task<List<HeadLineActor>> GetHeadLineActorsByVideoID(Guid videoId)
        //{
        //    return await _context.HeadLineActors.Where(x => x.VideoId == videoId).ToListAsync();
        //}
    }
}

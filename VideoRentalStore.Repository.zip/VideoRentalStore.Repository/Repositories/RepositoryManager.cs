﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using VideoRentalStore.ADT.Interfaces.RepositoryManager;
using VideoRentalStore.Database.DataContexts;

namespace VideoRentalStore.Repository.Repositories
{
    public class RepositoryManager: IRepositoryManager
    {
        private readonly VideoRentalStoreDb _context;

        public IBrowseTitleRepository BrowseTitleRepository { get; set; }
        public ILatestReleasesRepository LatestReleasesRepository { get; set; }
        public IRentalRepository RentalRepository { get; set; }
        public IVideoDetailsRepository VideoDetailsRepository { get; set; }

        public RepositoryManager(IBrowseTitleRepository browseTitleRepository, ILatestReleasesRepository latestReleasesRepository, IRentalRepository rentalRepository, IVideoDetailsRepository videoDetailsRepository)
        {
            _context = new VideoRentalStoreDb();
            BrowseTitleRepository = browseTitleRepository;
            LatestReleasesRepository = latestReleasesRepository;
            RentalRepository = rentalRepository;
            VideoDetailsRepository = videoDetailsRepository;
        }
        public void Dispose()
        {
            _context.Dispose();
        }
        public int SaveChanges()
        {
            return _context.SaveChanges();
        }

        public async Task<int> SaveChangesAsync()
        {
            int result = await _context.SaveChangesAsync();
            return result;
        }

        public async Task<int> SaveChangesAsync(CancellationToken cancellationToken)
        {
            return await _context.SaveChangesAsync(cancellationToken);
        }
    }
}

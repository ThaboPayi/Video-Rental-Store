﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Threading.Tasks;
using VideoRentalStore.ADT.Interfaces.RepositoryManager;
using VideoRentalStore.Core.ModelClasses;
using VideoRentalStore.Database.DataContexts;
using VideoRentalStore.Entities;

namespace VideoRentalStore.Repository.Repositories
{
    public class BrowseTitlesRepository : IBrowseTitleRepository
    {
        private readonly VideoRentalStoreDb _context;

        public BrowseTitlesRepository(VideoRentalStoreDb dbContext)
        {
            _context = dbContext;
        }

        public async Task<List<Video>> GetVideos()
        {
            var browseTitlesVideos = await _context.Videos.OrderBy(r => r.ReleaseDate).Distinct().Take(6).ToListAsync();
            return browseTitlesVideos;
        }

        public async Task<List<Genre>> GetGenres()
        {
            var browseTitlesGenres = await _context.Genres.OrderBy(r => r.GenreOrder).Distinct().Take(6).ToListAsync();
            return browseTitlesGenres;
        }

        public async Task<VideosModel> SearchVideo(string searchTerm, DateTime startDate, DateTime endDate,
            List<Genre> genres)
        {
            List<Video> vs = new List<Video>();

            VideosModel vsModel = new VideosModel();

            var headLineActors = await _context.HeadLineActors.Where(p => p.HeadLineActorText.Contains(searchTerm))
                .ToListAsync();

            var genre = await _context.Genres.Where(p => p.GenreText.Contains(searchTerm)).ToListAsync();


            var videos = await _context.Videos.Where(p => (p.Tittle.Contains(searchTerm) || p.Director.Contains(searchTerm)) || (p.ReleaseDate >= startDate || p.ReleaseDate <= endDate)).ToListAsync();

            var vg = genre.Join(videos, g => g.Id, v => v.Id, (g, v) => new { v = v, g = g }).Distinct().ToList().
                Select(p => new
                {
                    VideoID = p.v.Id,
                    Tittle = p.v.Tittle,
                    Director = p.v.Director,
                    Genres = p.v.Genres,
                    HeadLineActors = p.v.HeadLineActors,
                    ReleaseDate = p.v.ReleaseDate
                });
            var vgh = headLineActors.Join(vg, h => h.Id, v => v.VideoID, (h, v) => new { v = v, h = h })
                .Distinct().ToList().Select(p => new
                {
                    VideoId = p.v.VideoID,
                    Tittle = p.v.Tittle,
                    Director = p.v.Director,
                    Genres = p.v.Genres,
                    HeadLineActors = p.v.HeadLineActors,
                    ReleaseDate = p.v.ReleaseDate
                });

            foreach (var items in vgh)
            {
                vs.Add(
                    new Video
                    {
                        Tittle = items.Tittle,
                        Director = items.Director,
                        Genres = items.Genres,
                        HeadLineActors = items.HeadLineActors,
                        ReleaseDate = items.ReleaseDate,
                    });
            }

            vsModel = new VideosModel
            {
                VideosList = vs,
            };

            return vsModel;

        }
    }
}

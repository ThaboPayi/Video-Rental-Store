﻿CREATE TABLE [dbo].[HeadLineActors] (
    [Id]                 UNIQUEIDENTIFIER NOT NULL,
    [HeadLineActorText]  NVARCHAR (MAX)   NULL,
    [HeadLineActorOrder] INT              DEFAULT ((0)) NOT NULL,
    CONSTRAINT [PK_dbo.HeadLineActors] PRIMARY KEY CLUSTERED ([Id] ASC)
);


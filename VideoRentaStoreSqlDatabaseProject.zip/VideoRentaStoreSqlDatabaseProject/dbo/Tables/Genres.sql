﻿CREATE TABLE [dbo].[Genres] (
    [Id]         UNIQUEIDENTIFIER NOT NULL,
    [GenreText]  NVARCHAR (MAX)   NULL,
    [GenreOrder] INT              DEFAULT ((0)) NOT NULL,
    CONSTRAINT [PK_dbo.Genres] PRIMARY KEY CLUSTERED ([Id] ASC)
);


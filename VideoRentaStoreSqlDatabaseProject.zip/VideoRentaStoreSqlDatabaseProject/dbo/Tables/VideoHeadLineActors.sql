﻿CREATE TABLE [dbo].[VideoHeadLineActors] (
    [HeadLineActorId] UNIQUEIDENTIFIER NOT NULL,
    [VideoId]         UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_dbo.VideoHeadLineActors] PRIMARY KEY CLUSTERED ([VideoId] ASC, [HeadLineActorId] ASC),
    CONSTRAINT [FK_dbo.HeadLineActorVideos_dbo.HeadLineActors_HeadLineActor_Id] FOREIGN KEY ([HeadLineActorId]) REFERENCES [dbo].[HeadLineActors] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_dbo.HeadLineActorVideos_dbo.Videos_Video_Id] FOREIGN KEY ([VideoId]) REFERENCES [dbo].[Videos] ([Id]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_HeadLineActorId]
    ON [dbo].[VideoHeadLineActors]([HeadLineActorId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_VideoId]
    ON [dbo].[VideoHeadLineActors]([VideoId] ASC);


﻿CREATE TABLE [dbo].[VideoGenres] (
    [VideoId] UNIQUEIDENTIFIER NOT NULL,
    [GenreId] UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_dbo.VideoGenres] PRIMARY KEY CLUSTERED ([VideoId] ASC, [GenreId] ASC),
    CONSTRAINT [FK_dbo.VideoGenres_dbo.Genres_Genre_Id] FOREIGN KEY ([GenreId]) REFERENCES [dbo].[Genres] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_dbo.VideoGenres_dbo.Videos_Video_Id] FOREIGN KEY ([VideoId]) REFERENCES [dbo].[Videos] ([Id]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_VideoId]
    ON [dbo].[VideoGenres]([VideoId] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_GenreId]
    ON [dbo].[VideoGenres]([GenreId] ASC);


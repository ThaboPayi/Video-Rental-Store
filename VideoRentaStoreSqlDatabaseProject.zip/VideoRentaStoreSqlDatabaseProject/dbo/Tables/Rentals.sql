﻿CREATE TABLE [dbo].[Rentals] (
    [Id]       UNIQUEIDENTIFIER NOT NULL,
    [UserId]   INT              NOT NULL,
    [VideoId]  UNIQUEIDENTIFIER NOT NULL,
    [RentDate] DATETIME         NOT NULL,
    CONSTRAINT [PK_dbo.Rentals] PRIMARY KEY CLUSTERED ([Id] ASC)
);


﻿CREATE TABLE [dbo].[VideoCopies] (
    [Id]         UNIQUEIDENTIFIER NOT NULL,
    [VideoId]    UNIQUEIDENTIFIER NOT NULL,
    [NoOfCopies] INT              NOT NULL,
    CONSTRAINT [PK_dbo.VideoCopies] PRIMARY KEY CLUSTERED ([Id] ASC)
);


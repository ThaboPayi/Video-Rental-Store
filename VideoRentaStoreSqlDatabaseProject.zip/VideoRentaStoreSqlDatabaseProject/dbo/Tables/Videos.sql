﻿CREATE TABLE [dbo].[Videos] (
    [Id]          UNIQUEIDENTIFIER NOT NULL,
    [Tittle]      NVARCHAR (MAX)   NULL,
    [ReleaseDate] DATETIME         NOT NULL,
    [Director]    NVARCHAR (MAX)   NULL,
    [Image]       VARBINARY (MAX)  NULL,
    [NoOfCopies]  INT              DEFAULT ((0)) NOT NULL,
    CONSTRAINT [PK_dbo.Videos] PRIMARY KEY CLUSTERED ([Id] ASC)
);


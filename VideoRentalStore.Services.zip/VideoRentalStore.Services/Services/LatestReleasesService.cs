﻿using System.Collections.Generic;
using System.Threading.Tasks;
using VideoRentalStore.ADT.Interfaces;
using VideoRentalStore.ADT.Interfaces.RepositoryManager;
using VideoRentalStore.Core.ModelClasses;
using VideoRentalStore.Entities;

namespace VideoRentalStore.Services.Services
{
    public class LatestReleasesService : ILatestReleasesService
    {
        private readonly IRepositoryManager _repositoryManager;

        public LatestReleasesService(IRepositoryManager repositoryManager)
        {
            _repositoryManager = repositoryManager;
        }

        public Task<List<Video>> SearchByTerm(string searchTerm)
        {
            return _repositoryManager.LatestReleasesRepository.SearchByTerm(searchTerm);
        }

        public Task<List<Video>> GetLatestReleases()
        {
            return _repositoryManager.LatestReleasesRepository.GetLatestReleases();
        }
    }
}

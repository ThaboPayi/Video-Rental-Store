﻿using System;
using System.Threading.Tasks;
using VideoRentalStore.ADT.Interfaces;
using VideoRentalStore.ADT.Interfaces.RepositoryManager;
using VideoRentalStore.Core.ModelClasses;
using VideoRentalStore.Entities;

namespace VideoRentalStore.Services.Services
{
    public class VideoDetailsService : IVideoDetailsService
    {
        private readonly IRepositoryManager _repositoryManager;

        public VideoDetailsService(IRepositoryManager repositoryManager)
        {
            _repositoryManager = repositoryManager;
        }
        public Task<VideoDetailsModel> GetVideo(Guid videoId)
        {
            return _repositoryManager.VideoDetailsRepository.GetVideoDetasilsByVideoID(videoId);
        }
    }
}

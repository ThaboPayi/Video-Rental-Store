﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using VideoRentalStore.ADT.Interfaces;
using VideoRentalStore.ADT.Interfaces.RepositoryManager;
using VideoRentalStore.Core.ModelClasses;
using VideoRentalStore.Entities;

namespace VideoRentalStore.Services.Services
{
    public class BrowseTitlesService : IBrowseTitlesService
    {
        private readonly IRepositoryManager _repositoryManager;

        public BrowseTitlesService(IRepositoryManager repositoryManager)
        {
            _repositoryManager = repositoryManager;
        }
        public Task<List<Video>> GetVideos()
        {
            return _repositoryManager.BrowseTitleRepository.GetVideos();
        }

        public Task<List<Genre>> GetGenres()
        {
            return _repositoryManager.BrowseTitleRepository.GetGenres();
        }

        public Task<VideosModel> SearchWithFilters(string searchTerm, DateTime startDate, DateTime endDate, List<Genre> genres)
        {
            return _repositoryManager.BrowseTitleRepository.SearchVideo(searchTerm, startDate, endDate, genres);
        }
    }
}

﻿using System.Threading.Tasks;
using VideoRentalStore.ADT.Interfaces;
using VideoRentalStore.ADT.Interfaces.RepositoryManager;
using VideoRentalStore.Core.ModelClasses;

namespace VideoRentalStore.Services.Services
{
    public class RentalService : IRentalService
    {
        private readonly IRepositoryManager _repositoryManager;

        public RentalService(IRepositoryManager repositoryManager)
        {
            _repositoryManager = repositoryManager;
        }
        public Task RentVideoAsync(RentalModel rental)
        {
            return _repositoryManager.RentalRepository.RentVideoAsync(rental);
        }

    }
}

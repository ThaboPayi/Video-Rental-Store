﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dependency_Resolver.VideoServices;
using Ninject.Modules;
using VideoRentalStore.ADT.Interfaces.Injection;

namespace Dependency_Resolver
{
    public class CustomDependencyResolver : IDependencyResolver
    {
        public INinjectModule[] GetVideos()
        {
            var videos = new INinjectModule[]
            {
                new VideoInterfacesRepositoryBinder(),
            };
            return videos;
        }
    }
}
